Customizable wrench (standard M3,M4,M5,[...] and custom size) by Noisemaker00 on Thingiverse: https://www.thingiverse.com/thing:2131307

Summary:
This is a customizable wrench. You can:choose the nut sizechoose to have open nut-hole side, closed nut-hole side or boththe wrench ticknessYou can set nut size in two different ways:specify the metric nut size (eg. M4, M4, ... up to M20)specify a custom nut &gt;external&lt; diameter size in mmHow to:1) download OpensCAD2) open my file and follow instructions inside to customize3) click on "Render" (F6)4) click on "STL", save it and print